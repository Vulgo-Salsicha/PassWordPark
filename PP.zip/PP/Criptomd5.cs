﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;


namespace CriptoStringHash
{
    internal class Criptomd5
    {
        public string RetornarMd5(string Senha)
        {
            using (MD5 md5Hash = MD5.Create()) {
                return RetornarHash(md5Hash, Senha);


            }


        }








        private string RetornarHash(MD5 md5Hash, string input)
        {

            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));
            StringBuilder sBuilder = new StringBuilder();

            for (int i = 0; i < data.Length; i++) 
            {
                sBuilder.Append(data[i].ToString("X2"));


            };

            return sBuilder.ToString();




        }

        public bool CompararMD5(string senhaEntrada, string senhaMD5)
        {

            string senha = RetornarMd5(senhaEntrada);
            if (VerificarHash(senhaEntrada, senhaMD5)) {

                return true;


            }
            else
            {
                return false;
            }









        }

        private static bool VerificarHash(string input, string hash)
        {
            StringComparer comparar = StringComparer.OrdinalIgnoreCase;
            if (comparar.Compare(input, hash) == 0)
            {
                return true;
            }
            else
            {
                return false;

            }

        }
    }
}
