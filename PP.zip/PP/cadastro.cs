﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;


namespace PP
{
    public partial class cadastro : Form
    {
        public cadastro()
        {
            InitializeComponent();
        }

        private void cadastro_Load(object sender, EventArgs e)
        {
            string nomeu = Environment.UserName;
            lbl1c.Text = "Olá " + nomeu;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            var senhacad = textBox1.Text;

            CriptoStringHash.Criptomd5 pedro = new CriptoStringHash.Criptomd5();
          string senhacripto = pedro.RetornarMd5(textBox1.Text);






            try
            {
                string nomeusu = Environment.UserName;
                string pathcad = @"C:\Users\" + nomeusu + @"\AppData\LocalLow\PassWordPark\senhacad.txt";

            





                StreamWriter writer = new StreamWriter(pathcad, true, Encoding.UTF8);
               

               
                writer.Write(senhacripto);






                writer.Flush();
                writer.Dispose();
                writer.Close();
            }
            catch (Exception er)
            {
                Console.WriteLine("Exception: " + er.Message);
            }
            this.Close();


        }
    }
}