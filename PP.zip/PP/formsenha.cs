﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;

namespace PP
{
    public partial class PassWordPark : Form
    {
       

















public PassWordPark()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void versãoDoAppToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("A Versão deste Aplicativo é a 1.1");


        }

        private void sobreOPPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form sob = new sobre();
            sob.Show();


        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void PassWordPark_Load(object sender, EventArgs e)
        {
            #region Conectar a Base

            string basededados = Application.StartupPath + @"\db\dbSQLite.db";
            string strConnection = @"Data Source = " + basededados + "; Version = 3 ";

            if (!File.Exists(basededados))
            {

                SQLiteConnection.CreateFile(basededados);

            }




            SQLiteConnection Conexao = new SQLiteConnection(strConnection);
            //  Conexao.ConnectionString = strConnection;

            try
            {

                Conexao.Open();

            }
            catch (Exception ex)
            {
                labelresultado.Text = "Erro ao encontrar senhas\n" + ex;
            }
            finally
            {

                Conexao.Close();
            }

            #endregion




            #region Verificar/Criar base





           
            if (!File.Exists(basededados))
            {

                SQLiteConnection.CreateFile(basededados);
            }

                SQLiteConnection conexao = new SQLiteConnection(strConnection);

            try
            {
                conexao.Open();

                SQLiteCommand comando = new SQLiteCommand();
                comando.Connection = conexao;
                comando.CommandText = "CREATE TABLE senhas (id INT NOT NULL PRIMARY KEY, desc NVARCHAR(50), senha NVARCHAR(50))";
                comando.ExecuteNonQuery();

 
                comando.Dispose();



            }
            catch (Exception ex)
            {
                labelresultado.Text = "Menu:";


            }
            finally
            {
                conexao.Close();


            }

            #endregion


            #region Mostrar Base

           

          

            try
            {
                string query = "SELECT * FROM senhas";
               

                DataTable dados = new DataTable();
                SQLiteDataAdapter adaptador = new SQLiteDataAdapter(query, strConnection);

                conexao.Open();

                adaptador.Fill(dados);

                foreach (DataRow linha in dados.Rows)
                {
                    lista.Rows.Add(linha.ItemArray);

                }
            }
            catch (Exception ex)
            {
                lista.Rows.Clear();
               


            }
            finally
            {
                conexao.Close();


            }





            #endregion



        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            Form ac = new adicionarsenha();
            ac.Show();

            this.Close();













        }

       

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            string basededados = Application.StartupPath + @"\db\dbSQLite.db";
            string strConnection = @"Data Source = " + basededados + "; Version = 3 ";

            SQLiteConnection conexao = new SQLiteConnection(strConnection);
            try
            {
                conexao.Open();

                SQLiteCommand comando = new SQLiteCommand();
                comando.Connection = conexao;


               


                comando.CommandText = "DELETE FROM senhas WHERE id = '" + lista.CurrentRow.Cells[0].Value + "'";
                comando.ExecuteNonQuery();

                labelresultado.Text = "Senha apagada";
               
                comando.Dispose();



            }
            catch (Exception ex)
            {
                labelresultado.Text = ex.Message;


            }
            finally
            {
                this.Close();
                Form esse = new PassWordPark();
                esse.Show();
                conexao.Close();



            }







        }

        private void notasDeAtualizaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form an = new notaatualiza();
            an.Show();
        }
    }
    }

