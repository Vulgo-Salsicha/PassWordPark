﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP
{
    public partial class notaatualiza : Form
    {
        public notaatualiza()
        {
            InitializeComponent();
        }

        private void notaatualiza_Load(object sender, EventArgs e)
        {
            labelatualiza.Text = "Versão 1.1: \n" +
                "=> Melhorias de Design, agora ao inserir ou apagar uma senha a tabela é atualizada automaticamente; \n" +
                "=> Melhorias de Segurança na Senha Principal do Usuário; \n" +
                "=> Redimensionamento de janelas arrumado; \n" +
                "=> Adicionado Janela De Notas de Atualizações.";
        }
    }
}
