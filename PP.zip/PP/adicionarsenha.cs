﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PP
{


    public partial class adicionarsenha : Form
    {
        public adicionarsenha()
        {
            InitializeComponent();
        }

        private void btnconfirmar_Click(object sender, EventArgs e)
        {

           string Desc = txtdesc.Text;
            string pass = txtsenha.Text;

            string basededados = Application.StartupPath + @"\db\dbSQLite.db";
            string strConnection = @"Data Source = " + basededados + "; Version = 3 ";


            SQLiteConnection conexao = new SQLiteConnection(strConnection);

            try
            {
                conexao.Open();

                SQLiteCommand comando = new SQLiteCommand();
                comando.Connection = conexao;

                int id = new Random(DateTime.Now.Millisecond).Next(0, 10000);


             
                    comando.CommandText = "INSERT INTO senhas VALUES (" + id + ", '" + Desc + "','" + pass + "')";
                comando.ExecuteNonQuery();

                
                comando.Dispose();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }
            finally
            {

                MessageBox.Show("Senha adicionada");
                this.Close();
                


                conexao.Close();
                Form atualizatabela = new PassWordPark();
                atualizatabela.Show();


            }














        }

     
    }
}
