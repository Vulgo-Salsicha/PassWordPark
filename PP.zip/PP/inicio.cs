﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SQLite;

namespace PP
{
  
    public partial class inicio : Form
    {

        public inicio()
        {

            InitializeComponent();
        }

        private void btncadastro_Click(object sender, EventArgs e)
        {
            try
            {
                string nomeusu = Environment.UserName;
                string path = @"C:\Users\" + nomeusu + @"\AppData\LocalLow\PassWordPark\senhacad.txt";
              
                if (!File.Exists(path))
                {
                   
                    Form cd = new cadastro();
                    cd.Show();
                }
                else
                {

                    reslabel.ForeColor = Color.Red;
                    reslabel.Text = "Seu usuario já está cadastrado.";




                }


            }
            catch (Exception x)
            {

                MessageBox.Show("ola" + x);
            }
            
       



        }

        private void inicio_Load(object sender, EventArgs e)
        {


            Directory.CreateDirectory(Application.StartupPath + @"\db\");

            if (Directory.Exists(Application.StartupPath + @"\db\"))
            {

                File.Create(Application.StartupPath + @"\db\dbSQLite.db");

            }

           






            var nomeusu= Environment.UserName;
            label2.Text = "Olá " + nomeusu  ;

            string path = @"C:\Users\" + nomeusu + @"\AppData\LocalLow\PassWordPark\";
            if (!Directory.Exists(path))
            {

                Directory.CreateDirectory(path);

            }


         







        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nomeusu = Environment.UserName;
            
            
         
          string path = @"C:\Users\" + nomeusu + @"\AppData\LocalLow\PassWordPark\senhacad.txt";

            if (!File.Exists(path))
            {
                reslabel.Text = "Você ainda não está cadastrado";
                reslabel.ForeColor = Color.Red;
            }
            else
            {


                StreamReader reader = new StreamReader(path, Encoding.Default);

                string txt = reader.ReadToEnd();





                reader.Close();
                reader.Dispose();
               
                // Verificar senha criptografada

                CriptoStringHash.Criptomd5 pedro1 = new CriptoStringHash.Criptomd5();
                string suasenhacripto = pedro1.RetornarMd5(textsenha.Text);
              
                bool res = pedro1.CompararMD5(suasenhacripto, txt);

                if (res)
                {
                    Form cs = new PassWordPark();
                    cs.Show();

                }
                else
                {
                    reslabel.ForeColor = Color.Red;
                    reslabel.Text = "Senha Incorreta.";

                }

            }










        }
    }

}
